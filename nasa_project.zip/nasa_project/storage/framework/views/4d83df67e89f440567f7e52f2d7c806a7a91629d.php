<!doctype html>
<html lang="en">
  <head>
    <title> Line Graph Chart </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
  </head>
  <body>
 
    <div class="container p-5">
        <h5> date filter </h5>
        <form action="<?php echo e(route('filter')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <table style="width: 100%" cellpadding="5">
                                            <tr>
                                                <td>
        <input type="text" name="daterange" value="01/01/2015  - 01/01/2015 " class="form-control">
 
</td>
<td>
<button type="submit" class="btn btn-primary">Submit</button>
</td>
</tr>
</table>
</form>
    </div>
    <script type="text/javascript">
 $(function() {
     $('input[name="daterange"]').daterangepicker({
         timePicker: true,
         timePickerIncrement: 30,
         locale: {
             format: 'MM/DD/YYYY h:mm A'
         }
     });
 });
 </script> 
 
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    
</body>
</html> <?php /**PATH C:\XAMPP\htdocs\nasa\resources\views/chart.blade.php ENDPATH**/ ?>