<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
 
use Redirect,Response;
 
Use DB;

use Carbon\Carbon;

class LineController extends Controller
{
    //
    public function index()
    {
 
        return view('chart');
    }

    public function filter(){
        //echo "testing";
      
//$datefilter = $request->daterange;
       
         
          // $datefilterArr = explode('To', $datefilter);
           // $conditionv2 = $conditionv2." and complaints_last_updated_date=".$date."";			
           //   echo   $start_date  = $datefilterArr[0];
                //$end_date = $datefilterArr[1]; 
           
           //exit();
        $start_date="2015-09-07";
        $end_date="2015-09-08";
        //$url="https://api.nasa.gov/neo/rest/v1/feed?start_date='$start_date'&end_date='$end_date'&api_key=DEMO_KEY";
       $url="https://api.nasa.gov/neo/rest/v1/feed?start_date=2015-09-07&end_date=2015-09-08&api_key=DEMO_KEY";
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_URL, $url);
$result = curl_exec($ch);

//dd($result);
curl_close($ch);
$obj = json_decode($result);
echo "<pre>";
print_r($obj);
// echo $obj->element_count;
die();
//echo $obj->name;
foreach($obj as $value){
echo $value->start_date;
}

    }

}
