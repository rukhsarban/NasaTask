<?php
  
namespace App\Http\Controllers;
    
use Illuminate\Http\Request;
use App\Models\User;
use DB;
    
class ChartJSController extends Controller
{
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function index()
    {
        
       
      $url="https://api.nasa.gov/neo/?api_key=DEMO_KEY";
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_URL, $url);
$result = curl_exec($ch);

 $users= json_decode($result);
  $labels = $users->id;
  $data = $users->close_approach_data;

  //dd($users);
  //exit();
 
  
        return view('chart', compact('labels', 'data'));
        curl_close($ch);
    }
}